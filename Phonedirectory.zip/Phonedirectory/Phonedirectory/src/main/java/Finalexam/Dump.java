/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Finalexam;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Azrael
 */
public class Dump extends javax.swing.JFrame {

    /**
     * Creates new form Dump
     */
    public Dump() {
        initComponents();
        setSize(900, 500);
         jmobile.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        // Get the current text in the TextField
        String currentText = jmobile.getText();

        // Allow only digits and limit to three characters
        if (!Character.isDigit(e.getKeyChar()) || currentText.length() >= 14) { //Germany can have 14 digits in their mobile number
            e.consume(); // Ignore the typed key
        }
    }
});
         jtelephone.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        // Get the current text in the TextField
        String currentText = jtelephone.getText();

        // Allow only digits and limit to three characters
        if (!Character.isDigit(e.getKeyChar()) || currentText.length() >= 12) {
            e.consume(); // Ignore the typed key
        }
    }
});
//jname char restrict
        jname.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
            e.consume();
        }
    }
});

        //jname2 char restrict
        jname2.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
            e.consume();
        }
    }
});
        
        jcode.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        // Get the current text in the TextField
        String currentText = jcode.getText();

        // Allow only digits and limit to three characters
        if (!Character.isDigit(e.getKeyChar()) || currentText.length() >= 3) {
            e.consume(); // Ignore the typed key
        }
    }
});

        // window listener to the JFrame Combo Box
addWindowListener(new WindowAdapter() {
    @Override
    public void windowOpened(WindowEvent e) {
        // Hide the JComboBox when the window is opened
        countryComboBox.setVisible(false);
    }
});
//+signKeyListener


//ComboBox
jcode.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        updateComboBoxVisibility();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        updateComboBoxVisibility();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        updateComboBoxVisibility();
    }

    private void updateComboBoxVisibility() {
        String code = jcode.getText().trim();
        if (code.equals("1") || code.equals("61") || code.equals("44") || code.equals("49") ||
            code.equals("33") || code.equals("55") || code.equals("54") || code.equals("46") ||
            code.equals("34") || code.equals("39")) {
            countryComboBox.setVisible(true);
        } else {
            countryComboBox.setVisible(false);
        }
    }
});


        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

try {
    File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");
    BufferedReader br = new BufferedReader(new FileReader(file));

    String line;
    while ((line = br.readLine()) != null) {
        String[] data = line.split("\\s+");
        model.addRow(data);
    }

    br.close();
} catch (IOException ex) {
    Logger.getLogger(Sample.class.getName()).log(Level.SEVERE, null, ex);
}

String name = jname.getText().trim();
String lastName = jname2.getText().trim();
String mobile = jmobile.getText();
String telephone = jtelephone.getText();
String code = jcode.getText();
String countryName;

// Rest of your code...
    }
    
    
 private static boolean isDataAlreadyExists(File file, String newData) throws IOException {
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        String line;
        while ((line = br.readLine()) != null) {
            if (line.equals(newData)) {
                br.close();
                fr.close();
                return true;
            }
        }

        br.close();
        fr.close();
        return false;
    
        
 
 
 }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jsearch = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jname = new javax.swing.JTextField();
        jcode = new javax.swing.JTextField();
        jmobile = new javax.swing.JTextField();
        jtelephone = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jname2 = new javax.swing.JTextField();
        clear = new javax.swing.JButton();
        view = new javax.swing.JButton();
        countryComboBox = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("Phone Book");

        jsearch.setDisabledTextColor(new java.awt.Color(153, 153, 153));
        jsearch.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jsearchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jsearchFocusLost(evt);
            }
        });
        jsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jsearchActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Add New Contacts");

        jname.setText("First Name");
        jname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jnameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jnameFocusLost(evt);
            }
        });
        jname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jnameActionPerformed(evt);
            }
        });

        jcode.setText("Country code");
        jcode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jcodeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jcodeFocusLost(evt);
            }
        });
        jcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcodeActionPerformed(evt);
            }
        });

        jmobile.setText("Phone Number");
        jmobile.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jmobileFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jmobileFocusLost(evt);
            }
        });
        jmobile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmobileActionPerformed(evt);
            }
        });

        jtelephone.setText("Telephone Number");
        jtelephone.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jtelephoneFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtelephoneFocusLost(evt);
            }
        });
        jtelephone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtelephoneActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Edit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        exit.setBackground(new java.awt.Color(255, 102, 102));
        exit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton6.setText("Search");

        jname2.setText("Last Name");
        jname2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jname2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jname2FocusLost(evt);
            }
        });

        clear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        clear.setText("Clear");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        view.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        view.setText("View");
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewActionPerformed(evt);
            }
        });

        countryComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "USA (+1) ", "Canada (+1)", "Australia (+61)", "New Zealand (+61)" }));
        countryComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countryComboBoxActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name", "Mobile#", "Telephone#", "Province", "Country"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(477, 477, 477))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jsearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton6)
                        .addGap(489, 489, 489))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jtelephone, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(41, 41, 41)
                                .addComponent(clear))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(view, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jname, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jname2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jmobile, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(countryComboBox, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(531, Short.MAX_VALUE))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jsearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6))
                .addGap(6, 6, 6)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jname2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcode)
                    .addComponent(jmobile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(countryComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jtelephone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3)
                    .addComponent(view))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(exit, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clear, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(73, 73, 73))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jnameFocusLost
        // TODO add your handling code here:
        if(jname.getText().equals(""))
        {
            jname.setText("First Name");
        }
    }//GEN-LAST:event_jnameFocusLost

    private void jnameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jnameFocusGained
        // TODO add your handling code here:
        if(jname.getText().equals("First Name"))
        {
            jname.setText("");
        }
    }//GEN-LAST:event_jnameFocusGained

    private void jnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jnameActionPerformed

    private void jsearchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jsearchFocusGained
        // TODO add your handling code here:
        if(jsearch.getText().equals("Search"))
        {
            jsearch.setText("");
        }
    }//GEN-LAST:event_jsearchFocusGained

    private void jsearchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jsearchFocusLost
        // TODO add your handling code here:
        if(jsearch.getText().equals(""))
        {
            jsearch.setText("Search");
        }
    }//GEN-LAST:event_jsearchFocusLost

    private void jcodeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jcodeFocusGained
        // TODO add your handling code here:
         if(jcode.getText().equals("Country code"))
        {
            jcode.setText("");
        }
    }//GEN-LAST:event_jcodeFocusGained

    private void jcodeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jcodeFocusLost
        // TODO add your handling code here:
         if(jcode.getText().equals(""))
        {
            jcode.setText("Country code");
        }
    }//GEN-LAST:event_jcodeFocusLost

    private void jmobileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jmobileFocusGained
        // TODO add your handling code here:
         if(jmobile.getText().equals("Phone Number"))
        {
            jmobile.setText("");
        }
    }//GEN-LAST:event_jmobileFocusGained

    private void jmobileFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jmobileFocusLost
        // TODO add your handling code here:
         if(jmobile.getText().equals(""))
        {
            jmobile.setText("Phone Number");
        }
    }//GEN-LAST:event_jmobileFocusLost

    private void jtelephoneFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtelephoneFocusGained
        // TODO add your handling code here:
         if(jtelephone.getText().equals("Telephone Number"))
        {
            jtelephone.setText("");
        }
    }//GEN-LAST:event_jtelephoneFocusGained

    private void jtelephoneFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtelephoneFocusLost
        // TODO add your handling code here:
         if(jtelephone.getText().equals(""))
        {
            jtelephone.setText("Telephone Number");
        }
    }//GEN-LAST:event_jtelephoneFocusLost

    private void jsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jsearchActionPerformed

    private void jmobileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmobileActionPerformed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_jmobileActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
String name = jname.getText().trim();
String lastName = jname2.getText().trim();
String mobile = jmobile.getText();
String telephone = jtelephone.getText();
String code = jcode.getText();
String countryName;

if (code.equals("93")) {
    countryName = "Afghanistan";
} else if (code.equals("213")) {
    countryName = "Algeria";
} else {
    countryName = ""; // Empty string if code is not recognized
}

String provinceName = "";

if (telephone.equals("2")) {
    provinceName = "Metro Manila";
} else if (telephone.equals("32")) {
    provinceName = "Cebu";
}

// Set countryName based on countryComboBox selection
String countryOption = countryComboBox.getSelectedItem().toString();

if (countryOption.equals("USA (+1)")) {
    countryName = "USA";
} else if (countryOption.equals("Canada (+1)")) {
    countryName = "Canada";
}

String dataToWrite = name + " " + lastName + " " + mobile + " " + telephone + " " + countryName + " " + provinceName;

try {
    File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");

    // Check if data already exists in the file
    if (isDataAlreadyExists(file, dataToWrite)) {
        // Data already exists, show a message or take appropriate action
        JOptionPane.showMessageDialog(null, "Data already exists on the Table.");
    } else if (name.equals("First Name") || code.equals("Country code") || mobile.equals("Phone Number") || telephone.equals("Telephone Number") || lastName.equals("Last Name")) {
        if (name.equals("First Name")) {
            JOptionPane.showMessageDialog(null, "Please enter your first name");
        } else if (lastName.equals("Last Name")) {
            JOptionPane.showMessageDialog(null, "Please enter your last name");
        } else if (code.equals("Country code")) {
            JOptionPane.showMessageDialog(null, "Please enter your country code");
        } else if (mobile.equals("Mobile Number")) {
            JOptionPane.showMessageDialog(null, "Please enter your mobile number");
        } else if (telephone.equals("Telephone Number")) {
            JOptionPane.showMessageDialog(null, "Please enter your telephone number");
        }
    } else if (name.isEmpty() || lastName.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your first name and last name");
    } else if (mobile.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your mobile number");
    } else if (code.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your country code");
    } else if (telephone.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your telephone Number");
    } else {
        // Split the name by space and consider the first part as the name
        String[] nameParts = name.split("\\s+");
        String firstName = nameParts[0];

        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(dataToWrite);
        bw.newLine();
        bw.close();
        fw.close();

        // Add data to the table only if it's not already present
        boolean isDataAlreadyInTable = false;
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0).equals(firstName)) {
                isDataAlreadyInTable = true;
                break;
            }
        }

        if (!isDataAlreadyInTable) {
            model.addRow(new Object[]{firstName, lastName, mobile, telephone, countryName, provinceName});
        }
    }
} catch (IOException ex) {
    Logger.getLogger(Sample.class.getName()).log(Level.SEVERE, null, ex);
}


    }//GEN-LAST:event_jButton1ActionPerformed

    private void jcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcodeActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jcodeActionPerformed

    private void jtelephoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtelephoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtelephoneActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        // TODO add your handling code here:
        exit.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        System.exit(0); // Exit the program with status code 0
    }
});

    }//GEN-LAST:event_exitActionPerformed

    private void jname2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jname2FocusGained
        // TODO add your handling code here:
        if(jname2.getText().equals("Last Name"))
        {
            jname2.setText("");
        }
    }//GEN-LAST:event_jname2FocusGained

    private void jname2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jname2FocusLost
        // TODO add your handling code here:
        if(jname2.getText().equals(""))
        {
            jname2.setText("Last Name");
        }
    }//GEN-LAST:event_jname2FocusLost

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
   clear.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        // Clear the input fields
        if (!jname.getText().equals("First Name")) {
            jname.setText("First Name");
        }
        if (!jname2.getText().equals("Last Name")) {
            jname2.setText("Last Name");
        }
        if (!jcode.getText().equals("Country code")) {
            jcode.setText("Country code");
        }
        if (!jmobile.getText().equals("Mobile Number")) {
            jmobile.setText("Mobile Number");
        }
        if (!jtelephone.getText().equals("Telephone Number")) {
            jtelephone.setText("Telephone Number");
        }

        // Reset or update any other components or data
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear the table

        // Read the data from the file and populate the table
        try {
            File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(" ");
                model.addRow(data);
            }
            reader.close();
        } catch (IOException ex) {
            Logger.getLogger(Sample.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
});


    }//GEN-LAST:event_clearActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void viewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewActionPerformed
        // TODO add your handling code here:
        view.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int rowCount = model.getRowCount();
        int columnCount = model.getColumnCount();

        // Iterate over the table data and display it
        for (int row = 0; row < rowCount; row++) {
            for (int col = 0; col < columnCount; col++) {
                Object cellValue = model.getValueAt(row, col);
                System.out.print(cellValue + " ");
            }
            System.out.println(); // Move to the next row
        }
    }
});
       
        //comboBox
       jcode.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        String code = jcode.getText().trim();
        
        if (code.equals("1")) {
            // Show the JComboBox
            countryComboBox.setVisible(true);
        } else {
            // Hide the JComboBox
            countryComboBox.setVisible(false);
        }
    }
});
    }//GEN-LAST:event_viewActionPerformed

    private void countryComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countryComboBoxActionPerformed
        // TODO add your handling code here:
        countryComboBox.setVisible(false);

    }//GEN-LAST:event_countryComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dump.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dump.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dump.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dump.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dump().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clear;
    private javax.swing.JComboBox<String> countryComboBox;
    private javax.swing.JButton exit;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jcode;
    private javax.swing.JTextField jmobile;
    private javax.swing.JTextField jname;
    private javax.swing.JTextField jname2;
    private javax.swing.JTextField jsearch;
    private javax.swing.JTextField jtelephone;
    private javax.swing.JButton view;
    // End of variables declaration//GEN-END:variables
}
