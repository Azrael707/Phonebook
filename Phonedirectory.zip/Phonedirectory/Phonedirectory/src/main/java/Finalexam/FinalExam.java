/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Finalexam;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Azrael
 */
public class FinalExam extends javax.swing.JFrame {

    /**
     * Creates new form FinalExam
     */
    public FinalExam() {
        initComponents();
        
         jmobile.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        // Get the current text in the TextFields
        String currentText = jmobile.getText();
        String countryCode = jcode.getText();

        // Allow only digits and limit to 11 characters when countryCode is "63"
        if (!Character.isDigit(e.getKeyChar()) || (countryCode.equals("63") && currentText.length() >= 11) || currentText.length() >= 14) {
            e.consume(); // Ignore the typed key
        }
    }
});

        
         
        jtelephone.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        // Get the current text in the TextField
        String currentText = jtelephone.getText();

        // Allow only digits, "(", ")", and "-" characters and limit to twelve characters
        if (!Character.isDigit(e.getKeyChar()) && e.getKeyChar() != '(' && e.getKeyChar() != ')' && e.getKeyChar() != '-' || currentText.length() >= 12) {
            e.consume(); // Ignore the typed key
        }
    }
});
//jname char restrict
        jname.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
            e.consume();
        }
    }
});

        //jname2 char restrict
        jname2.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        char c = e.getKeyChar();
        if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
            e.consume();
        }
    }
});
        //Jcode inout Limit
        jcode.addKeyListener(new KeyAdapter() {
    @Override
    public void keyTyped(KeyEvent e) {
        // Get the current text in the TextField
        String currentText = jcode.getText();

        // Allow only digits and limit to three characters
        if (!Character.isDigit(e.getKeyChar()) || currentText.length() >= 3) {
            e.consume(); // Ignore the typed key
        }
    }
});


        // window listener to the JFrame Combo Box
addWindowListener(new WindowAdapter() {
    @Override
    public void windowOpened(WindowEvent e) {
        // Hide the JComboBox when the window is opened
        countryComboBox.setVisible(false);
    }
});
//areacode
addWindowListener(new WindowAdapter() {
    @Override
    public void windowOpened(WindowEvent e) {
        // Hide the JComboBox when the window is opened
        areacode.setVisible(false);
    }
});


//Telephone
jtelephone.setVisible(false);



//ComboBox jcountry && jtelephone Visible
jcode.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        updateTextFieldVisibility();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        updateTextFieldVisibility();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        updateTextFieldVisibility();
    }

    // Method to update the visibility of text fields based on the entered code
    private void updateTextFieldVisibility() {
        // Get the code entered in the jcode TextField and trim any leading/trailing spaces
        String code = jcode.getText().trim();

        // Check the entered code and update the visibility of the countryComboBox and jtelephone fields accordingly
        if (code.equals("1") || code.equals("44")) {
            // If the code is "1" or "44", make the countryComboBox visible
            countryComboBox.setVisible(true);
        } else if (code.equals("63")) {
            // If the code is "63", make the jtelephone field visible
            jtelephone.setVisible(true);
        } else {
            // If none of the above conditions match, hide both the countryComboBox and jtelephone fields
            countryComboBox.setVisible(false);
            jtelephone.setVisible(false);
        }
    }
});







//Combo box areacode
jtelephone.getDocument().addDocumentListener(new DocumentListener() {
    @Override
    public void insertUpdate(DocumentEvent e) {
        updateComboBoxVisibility();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        updateComboBoxVisibility();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        updateComboBoxVisibility();
    }

    // Method to update the visibility of the areacode ComboBox based on the entered telephone code
    private void updateComboBoxVisibility() {
        // Get the telephone code entered in the jtelephone TextField and trim any leading/trailing spaces
        String code = jtelephone.getText().trim();

        // Check the entered code and update the visibility of the areacode ComboBox accordingly
        if (code.startsWith("(02)") || code.startsWith("(33)") || code.equals("(35)") || code.equals("(36)") || code.equals("(42)") || code.equals("(43)") || code.equals("(44)") || code.equals("(45)") || code.equals("(47)") || code.equals("(52)") || code.equals("(53)") || code.equals("(54)") || code.equals("(55)") || code.equals("(56)") || code.equals("(62)") || code.equals("(63)") || code.equals("(64)") || code.equals("(65)") || code.equals("(68)") || code.equals("(72)") || code.equals("(74)") || code.equals("(75)") || code.equals("(77)") || code.equals("(78)") || code.equals("(82)") || code.equals("(83)") || code.equals("(84)") || code.equals("(85)") || code.equals("(86)") || code.equals("(87)") || code.equals("(88)")) {
            // If the code matches any of the specified area codes, make the areacode ComboBox visible
            areacode.setVisible(true);
        } else {
            // If the entered code does not match any of the specified area codes, hide the areacode ComboBox
            areacode.setVisible(false);
        }
    }
});



//+signKeyListener
DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
model.setRowCount(0); // Clear the existing rows in the table

try {
    // Create a File object representing the file path
    File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");

    // Create a BufferedReader to read from the file
    BufferedReader br = new BufferedReader(new FileReader(file));

    String line;
    while ((line = br.readLine()) != null) {
        // Split the line into an array of data using comma as the delimiter
        String[] data = line.split(",");

        // Check if the array has at least 6 elements
        if (data.length >= 6) {
            // Extract the individual data elements from the array
            String firstName = data[0];
            String lastName = data[1];
            String mobile = data[2];
            String telephone = data[3];
            String provinceName = data[4];
            String countryName = data[5];

            // Add a row to the table with the extracted data
            model.addRow(new Object[]{firstName, lastName, mobile, telephone, provinceName, countryName});
        }
    }

    // Close the BufferedReader
    br.close();
} catch (IOException ex) {
    // Handle any IOException that occurs
    ex.printStackTrace();
}

    }
    
    //Add Button
 private static boolean isDataAlreadyExists(File file, String newData) throws IOException {
    FileReader fr = new FileReader(file);
    BufferedReader br = new BufferedReader(fr);

    String line;
    while ((line = br.readLine()) != null) {
        // Check if the current line is equal to the new data
        if (line.equals(newData)) {
            br.close();
            fr.close();
            return true; // Data already exists in the file
        }
    }

    br.close();
    fr.close();
    return false; // Data does not exist in the file
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        jsave = new javax.swing.JButton();
        jedit = new javax.swing.JButton();
        jdelete = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jsearch = new javax.swing.JTextField();
        jname2 = new javax.swing.JTextField();
        jname = new javax.swing.JTextField();
        jcode = new javax.swing.JTextField();
        jmobile = new javax.swing.JTextField();
        countryComboBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jtelephone = new javax.swing.JTextField();
        areacode = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 102, 102));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jsave.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jsave.setText("Save");
        jsave.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jsaveActionPerformed(evt);
            }
        });
        getContentPane().add(jsave, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 90, 40));

        jedit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jedit.setText("Edit");
        jedit.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jeditActionPerformed(evt);
            }
        });
        getContentPane().add(jedit, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 360, 90, 40));

        jdelete.setBackground(new java.awt.Color(255, 102, 102));
        jdelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jdelete.setText("Delete");
        jdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jdeleteActionPerformed(evt);
            }
        });
        getContentPane().add(jdelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 550, -1, 26));

        clear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        clear.setText("Clear");
        clear.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 255, 102), 2));
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        getContentPane().add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, 70, -1));

        exit.setBackground(new java.awt.Color(255, 102, 102));
        exit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        getContentPane().add(exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 550, 80, 30));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Phone Book");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jsearch.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jsearch.setDisabledTextColor(new java.awt.Color(153, 153, 153));
        jsearch.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jsearchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jsearchFocusLost(evt);
            }
        });
        jsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jsearchActionPerformed(evt);
            }
        });
        jsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jsearchKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jsearchKeyTyped(evt);
            }
        });
        getContentPane().add(jsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 210, 30));

        jname2.setText("Last Name");
        jname2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jname2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jname2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jname2FocusLost(evt);
            }
        });
        jname2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jname2ActionPerformed(evt);
            }
        });
        getContentPane().add(jname2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 120, 40));

        jname.setText("First Name");
        jname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jnameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jnameFocusLost(evt);
            }
        });
        jname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jnameActionPerformed(evt);
            }
        });
        getContentPane().add(jname, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 130, 40));

        jcode.setText("Country code");
        jcode.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jcode.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jcodeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jcodeFocusLost(evt);
            }
        });
        jcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcodeActionPerformed(evt);
            }
        });
        jcode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jcodeKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jcodeKeyTyped(evt);
            }
        });
        getContentPane().add(jcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 80, 40));

        jmobile.setText("Phone Number");
        jmobile.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jmobile.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jmobileFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jmobileFocusLost(evt);
            }
        });
        jmobile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmobileActionPerformed(evt);
            }
        });
        getContentPane().add(jmobile, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 170, 40));

        countryComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        countryComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "USA (+1)", "Canada (+1)", "Antigua and Barbuda (+1)", "Bahamas (+1)", "Barbados (+1)", "Bermuda (+1)", "British Virgin Islands (+1)", "Cayman Islands (+1)", "Dominica (+1)", "Dominican Republic (+1)", "Grenada (+1)", "Jamaica (+1)", "Montserrat (+1)", "Puerto Rico (+1)", "Saint Kitts and Nevis (+1)", "Saint Lucia (+1)", "Saint Vincent and the Grenadines (+1)", "Trinidad and Tobago (+1)", "Turks and Caicos Islands (+1)", "U.S. Virgin Islands (+1)", "Guernsey (+44)", "Jersey (+44)", "United Kingdom (+44)" }));
        countryComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countryComboBoxActionPerformed(evt);
            }
        });
        countryComboBox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                countryComboBoxKeyTyped(evt);
            }
        });
        getContentPane().add(countryComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 230, 30));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Add New Contacts");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 210, 40));

        jtelephone.setText("Telephone Number (xx)xxx-xxxx");
        jtelephone.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jtelephone.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jtelephoneFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtelephoneFocusLost(evt);
            }
        });
        jtelephone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtelephoneActionPerformed(evt);
            }
        });
        getContentPane().add(jtelephone, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 260, 40));

        areacode.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        areacode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Metro Manila (02)", "Rizal (02)", "Cavite (02)", "Laguna (02)", "Iloilo (33)", "Guimaras (33)", "Negros Oriental (35)", "Siquijor (35)", "Aklan (36)", "Antique (36)", "Capiz (36)", "Aurora (42)", "Marinduque (42)", "Quezon (42)", "Romblon (42)", "Batangas (43)", "Occidental Mindoro (43)", "Oriental Mindoro (43)", "Bulacan (44)", "Nueva Ecija (44)", "Pampanga (45)", "Tarlac (45)", "Bataan (47)", "Zambales (47)", "Albay (52)", "Catanduanes (52)", "Biliran (53)", "Leyte (53)", "Southern Leyte (53)", "Camarines Norte (54)", "Camarines Sur (54)", "Eastern Samar (55)", "Northern Samar (55)", "Western Samar (55)", "Masbate (56)", "Sorsogon (56)", "Basilan (62)", "Zamboanga del Sur (62)", "Zamboanga Sibugay (62)", "Lanao del Norte (63)", "Lanao del Sur (63)", "Cotabato (64)", "Maguindanao del Norte (64)", "Maguindanao del Sur (64)", "Sultan Kudarat (64)", "Sulu (68)", "Tawi-Tawi (68)", "Abra (74)", "Apayao (74)", "Benguet (74)", "Ifugao (74)", "Kalinga (74)", "Mountain Province (74)", "Ilocos Norte  (77)", "Ilocos Sur (77)", "Batanes (78)", "Cagayan (78)", "Isabela (78)", "Nueva Vizcaya (78)", "Quirino (78)", "Davao del Sur (82)", "Davao Occidental (82)", "Sarangani (83)", "South Cotabato (83)", "Davao de Oro (84)", "Davao del Norte (84)", "Agusan del Norte (85)", "Agusan del Sur (85)", "Dinagat Islands (86)", "Surigao del Norte (86)", "Surigao del Sur (86)", "Bukidnon (88)", "Camiguin (88)", "Misamis Occidental (88)", "Misamis Oriental (88)" }));
        areacode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                areacodeActionPerformed(evt);
            }
        });
        getContentPane().add(areacode, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 230, 30));

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Add");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 204), 2));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 90, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "First Name", "Last Name", "Country", "Mobile#", "Telephone#", "Province"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 660, 530));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 260, 10));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 260, 10));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Search");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 40, 70, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\ADMIN\\Desktop\\Dump\\My project.png")); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 780, 580));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\ADMIN\\Desktop\\Dump\\Sacramento color.png")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jnameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jnameFocusGained
        // TODO add your handling code here:
        if(jname.getText().equals("First Name"))
        {
            jname.setText("");
        }
    }//GEN-LAST:event_jnameFocusGained

    private void jnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jnameFocusLost
        // TODO add your handling code here:
        if(jname.getText().equals(""))
        {
            jname.setText("First Name");
        }
    }//GEN-LAST:event_jnameFocusLost

    private void jnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jnameActionPerformed

    private void jname2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jname2FocusGained
        // TODO add your handling code here:
        if(jname2.getText().equals("Last Name"))
        {
            jname2.setText("");
        }
    }//GEN-LAST:event_jname2FocusGained

    private void jname2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jname2FocusLost
        // TODO add your handling code here:
        if(jname2.getText().equals(""))
        {
            jname2.setText("Last Name");
        }
    }//GEN-LAST:event_jname2FocusLost

    private void jcodeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jcodeFocusGained
        // TODO add your handling code here:
        if(jcode.getText().equals("Country code"))
        {
            jcode.setText("");
        }
    }//GEN-LAST:event_jcodeFocusGained

    private void jcodeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jcodeFocusLost
        // TODO add your handling code here:
        if(jcode.getText().equals(""))
        {
            jcode.setText("Country code");
        }
    }//GEN-LAST:event_jcodeFocusLost

    private void jcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcodeActionPerformed

    private void jmobileFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jmobileFocusGained
        // TODO add your handling code here:
        if(jmobile.getText().equals("Phone Number"))
        {
            jmobile.setText("");
        }
    }//GEN-LAST:event_jmobileFocusGained

    private void jmobileFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jmobileFocusLost
        // TODO add your handling code here:
        if(jmobile.getText().equals(""))
        {
            jmobile.setText("Phone Number");
        }
    }//GEN-LAST:event_jmobileFocusLost

    private void jmobileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmobileActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jmobileActionPerformed

    private void jname2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jname2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jname2ActionPerformed

    private void jcodeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jcodeKeyTyped
        // TODO add your handling code here:

    }//GEN-LAST:event_jcodeKeyTyped

    private void jcodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jcodeKeyReleased
        // TODO add your handling code here:
 
    }//GEN-LAST:event_jcodeKeyReleased

    private void jsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jsaveActionPerformed
        // TODO add your handling code here:
        // Get the model of the jTable1, which is a DefaultTableModel
DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

try {
    // Create a File object representing the file path
    File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");

    // Create a BufferedWriter to write to the file
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));

    // Get the number of rows and columns in the table model
    int rowCount = model.getRowCount();
    int columnCount = model.getColumnCount();

    // Iterate over each row in the table
    for (int row = 0; row < rowCount; row++) {
        // Iterate over each column in the table
        for (int col = 0; col < columnCount; col++) {
            // Get the value at the current row and column
            String value = model.getValueAt(row, col).toString();

            // Write the value to the file
            bw.write(value);

            // If it's not the last column, add a comma delimiter
            if (col < columnCount - 1) {
                bw.write(",");
            }
        }

        // Move to the next line in the file
        bw.newLine();
    }

    // Close the BufferedWriter
    bw.close();
} catch (IOException ex) {
    // Handle any IOException that occurs
    ex.printStackTrace();
}

    }//GEN-LAST:event_jsaveActionPerformed

    private void areacodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_areacodeActionPerformed
        // TODO add your handling code here:
        areacode.setVisible(false);
    }//GEN-LAST:event_areacodeActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Clear the input fields
                if (!jname.getText().equals("First Name")) {
                    jname.setText("First Name");
                }
                if (!jname2.getText().equals("Last Name")) {
                    jname2.setText("Last Name");
                }
                if (!jcode.getText().equals("Country code")) {
                    jcode.setText("Country code");
                }
                if (!jmobile.getText().equals("Phone Number")) {
                    jmobile.setText("Phone Number");
                }
                if (!jtelephone.getText().equals("Telephone Number (xx)xxx-xxxx")) {
                    jtelephone.setText("Telephone Number (xx)xxx-xxxx");
                }

                // Reset or update any other components or data
                // No need to clear the table or read data from the file

            }
        });

    }//GEN-LAST:event_clearActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        // TODO add your handling code here:
       exit.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Display a confirmation dialog asking the user if they want to exit
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Confirmation", JOptionPane.YES_NO_OPTION);

        // Check if the user clicked "Yes" in the confirmation dialog
        if (confirm == JOptionPane.YES_OPTION) {
            // Display a message dialog with "THANK YOU!"
            JOptionPane.showMessageDialog(null, "THANK YOU!");

            // Exit the program with status code 0
            System.exit(0);
        }
    }
});

    }//GEN-LAST:event_exitActionPerformed

    private void jdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jdeleteActionPerformed
        // TODO add your handling code here:
      jdelete.addActionListener(new ActionListener() {
    boolean showMessage = true; // Flag to track if the message has been displayed

    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            if (showMessage) {
                JOptionPane.showMessageDialog(null, "Please Select a Data to Delete");
                showMessage = false; // Set the flag to false after displaying the message
            }
            return; // Exit the listener if no row is selected
        }

        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the selected data?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.removeRow(selectedRow);

            // Save the updated data to the file
            try {
                File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");

                BufferedWriter bw = new BufferedWriter(new FileWriter(file));

                int rowCount = model.getRowCount();
                int columnCount = model.getColumnCount();

                // Iterate over each row in the table
                for (int row = 0; row < rowCount; row++) {
                    // Iterate over each column in the table
                    for (int col = 0; col < columnCount; col++) {
                        // Get the value at the current row and column
                        String value = model.getValueAt(row, col).toString();

                        // Write the value to the file
                        bw.write(value);

                        // If it's not the last column, add a comma delimiter
                        if (col < columnCount - 1) {
                            bw.write(",");
                        }
                    }

                    // Move to the next line in the file
                    bw.newLine();
                }

                // Close the BufferedWriter
                bw.close();

                JOptionPane.showMessageDialog(null, "Deleted Successfully");
                showMessage = true; // Reset the flag after successful deletion
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        jdelete.setSelected(false); // Deselect the delete button
    }
});

    }//GEN-LAST:event_jdeleteActionPerformed

    private void jeditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jeditActionPerformed
            // TODO add your handling code here:
        jedit.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please Select a Data to Edit");
            return;
        }

        String fullName = jname.getText().trim();
        String firstName = fullName;
        String lastName = jname2.getText().trim();
        String mobile = jmobile.getText();
        String telephone = jtelephone.getText();
        String code = jcode.getText();
        String countryName = "";

        if (code.equals("93")) {
            countryName = "Afghanistan";
        } else if (code.equals("213")) {
            countryName = "Algeria";
            } else if (code.equals("376")) {
            countryName = "Andorra";
        } else if (code.equals("244")) {
            countryName = "Angola";
        } else if (code.equals("672")) {
            countryName = "Antartica";
        } else if (code.equals("54")) {
            countryName = "Argentina";
        } else if (code.equals("374")) {
            countryName = "Armenia";
        } else if (code.equals("297")) {
            countryName = "Aruba";
        } else if (code.equals("61")) {
            countryName = "Australia";
        } else if (code.equals("43")) {
            countryName = "Austria";
        } else if (code.equals("994")) {
            countryName = "Azerbaijan";
        } else if (code.equals("973")) {
            countryName = "Bahrain";
        } else if (code.equals("880")) {
            countryName = "Bangladesh";
        } else if (code.equals("375")) {
            countryName = "Belarus";
        } else if (code.equals("32")) {
            countryName = "Belgium";
        } else if (code.equals("501")) {
            countryName = "Belize";
        } else if (code.equals("229")) {
            countryName = "Benin";
        } else if (code.equals("975")) {
            countryName = "Bhutan";
        } else if (code.equals("387")) {
            countryName = "Bosnia and Herzegovina";
        } else if (code.equals("267")) {
            countryName = "Botswana";
        } else if (code.equals("55")) {
            countryName = "Brazil";
        } else if (code.equals("673")) {
            countryName = "Brunei";
        } else if (code.equals("359")) {
            countryName = "Bulgaria";
        } else if (code.equals("226")) {
            countryName = "Burkina Faso";
        } else if (code.equals("257")) {
            countryName = "Burundi";
        } else if (code.equals("855")) {
            countryName = "Cambodia";
        } else if (code.equals("237")) {
            countryName = "Cameroon";
        } else if (code.equals("238")) {
            countryName = "Cape Verde";
        } else if (code.equals("236")) {
            countryName = "Central African Republic";
        } else if (code.equals("235")) {
            countryName = "Chad";
        } else if (code.equals("56")) {
            countryName = "Chile";
        } else if (code.equals("86")) {
            countryName = "China";
        } else if (code.equals("57")) {
            countryName = "Colombia";
        } else if (code.equals("269")) {
            countryName = "Comoros";
        } else if (code.equals("682")) {
            countryName = "Cook Islands";
        } else if (code.equals("506")) {
            countryName = "Costa Rica";
        } else if (code.equals("385")) {
            countryName = "Croatia";
        } else if (code.equals("53")) {
            countryName = "Cuba";
        } else if (code.equals("599")) {
            countryName = "Curacao";
        } else if (code.equals("357")) {
            countryName = "Cyprus";
        } else if (code.equals("420")) {
            countryName = "Czech Republic";
        } else if (code.equals("243")) {
            countryName = "Democratic Republic of the Congo";
        } else if (code.equals("45")) {
            countryName = "Denmark";
        } else if (code.equals("253")) {
            countryName = "Djibouti";
        } else if (code.equals("670")) {
            countryName = "East Timor";
        } else if (code.equals("593")) {
            countryName = "Ecuador";
        } else if (code.equals("20")) {
            countryName = "Egypt";
        } else if (code.equals("503")) {
            countryName = "El Salvador";
        } else if (code.equals("240")) {
            countryName = "Equatorial Guinea";
        } else if (code.equals("291")) {
            countryName = "Eritrea";
        } else if (code.equals("372")) {
            countryName = "Estonia";
        } else if (code.equals("251")) {
            countryName = "Ethiopia";
        } else if (code.equals("500")) {
            countryName = "Falkland Islands";
        } else if (code.equals("298")) {
            countryName = "Faroe Islands";
        } else if (code.equals("679")) {
            countryName = "Fiji";
        } else if (code.equals("358")) {
            countryName = "Finland";
        } else if (code.equals("33")) {
            countryName = "France";
        } else if (code.equals("689")) {
            countryName = "French Polynesia";
        } else if (code.equals("241")) {
            countryName = "Gabon";
        } else if (code.equals("220")) {
            countryName = "Gambia";
        } else if (code.equals("995")) {
            countryName = "Georgia";
        } else if (code.equals("49")) {
            countryName = "Germany";
        } else if (code.equals("233")) {
            countryName = "Ghana";
        } else if (code.equals("350")) {
            countryName = "Gibraltar";
        } else if (code.equals("30")) {
            countryName = "Greece";
        } else if (code.equals("299")) {
            countryName = "Greenland";
        } else if (code.equals("1-671")) {
            countryName = "Guam";
        } else if (code.equals("502")) {
            countryName = "Guatemala";
        } else if (code.equals("224")) {
            countryName = "Guinea";
        } else if (code.equals("245")) {
            countryName = "Guinea-Bissau";
        } else if (code.equals("592")) {
            countryName = "Guyana";
        } else if (code.equals("509")) {
            countryName = "Haiti";
        } else if (code.equals("504")) {
            countryName = "Honduras";
        } else if (code.equals("852")) {
            countryName = "Hong Kong";
        } else if (code.equals("36")) {
            countryName = "Hungary";
        } else if (code.equals("354")) {
            countryName = "Iceland";
        } else if (code.equals("91")) {
            countryName = "India";
        } else if (code.equals("62")) {
            countryName = "Indonesia";
        } else if (code.equals("98")) {
            countryName = "Iran";
        } else if (code.equals("964")) {
            countryName = "Iraq";
        } else if (code.equals("353")) {
            countryName = "Ireland";
        } else if (code.equals("972")) {
            countryName = "Israel";
        } else if (code.equals("39")) {
            countryName = "Italy";
        } else if (code.equals("225")) {
            countryName = "Ivory Coast";
        } else if (code.equals("81")) {
            countryName = "Japan";
        } else if (code.equals("962")) {
            countryName = "Jordan";
        } else if (code.equals("254")) {
            countryName = "Kenya";
        } else if (code.equals("686")) {
            countryName = "Kiribati";
        } else if (code.equals("383")) {
            countryName = "Kosovo";
        } else if (code.equals("591")) {
            countryName = "Bolivia";
        } else if (code.equals("965")) {
            countryName = "Kuwait";
        } else if (code.equals("996")) {
            countryName = "Kyrgyzstan";
        } else if (code.equals("856")) {
            countryName = "Laos";
        } else if (code.equals("371")) {
            countryName = "Latvia";
        } else if (code.equals("961")) {
            countryName = "Lebanon";
        } else if (code.equals("266")) {
            countryName = "Lesotho";
        } else if (code.equals("231")) {
            countryName = "Liberia";
        } else if (code.equals("218")) {
            countryName = "Libya";
        } else if (code.equals("423")) {
            countryName = "Liechtenstein";
        } else if (code.equals("370")) {
            countryName = "Lithuania";
        } else if (code.equals("352")) {
            countryName = "Luxembourg";
        } else if (code.equals("853")) {
            countryName = "Macau";
        } else if (code.equals("389")) {
            countryName = "Macedonia";
        } else if (code.equals("261")) {
            countryName = "Madagascar";
        } else if (code.equals("265")) {
            countryName = "Malawi";
        } else if (code.equals("60")) {
            countryName = "Malaysia";
        } else if (code.equals("960")) {
            countryName = "Maldives";
        } else if (code.equals("223")) {
            countryName = "Mali";
        } else if (code.equals("356")) {
            countryName = "Malta";
        } else if (code.equals("692")) {
            countryName = "Marshall Islands";
        } else if (code.equals("222")) {
            countryName = "Mauritania";
        } else if (code.equals("230")) {
            countryName = "Mauritius";
        } else if (code.equals("262")) {
            countryName = "Mayotte";
        } else if (code.equals("52")) {
            countryName = "Mexico";
        } else if (code.equals("691")) {
            countryName = "Micronesia";
        } else if (code.equals("373")) {
            countryName = "Moldova";
        } else if (code.equals("377")) {
            countryName = "Monaco";
        } else if (code.equals("976")) {
            countryName = "Mongolia";
        } else if (code.equals("382")) {
            countryName = "Montenegro";
        } else if (code.equals("258")) {
            countryName = "Mozambique";
        } else if (code.equals("95")) {
            countryName = "Myanmar";
        } else if (code.equals("264")) {
            countryName = "Namibia";
        } else if (code.equals("674")) {
            countryName = "Nepal";
        } else if (code.equals("31")) {
            countryName = "Netherlands";
        } else if (code.equals("687")) {
            countryName = "New Caledonia";
        } else if (code.equals("64")) {
            countryName = "New Zealand";
        } else if (code.equals("505")) {
            countryName = "Nicaragua";
        } else if (code.equals("227")) {
            countryName = "Niger";
        } else if (code.equals("234")) {
            countryName = "Nigeria";
        } else if (code.equals("683")) {
            countryName = "Niue";
        } else if (code.equals("850")) {
            countryName = "North Korea";
        } else if (code.equals("47")) {
            countryName = "Norway";
        } else if (code.equals("968")) {
            countryName = "Oman";
        } else if (code.equals("92")) {
            countryName = "Pakistan";
        } else if (code.equals("680")) {
            countryName = "Palau";
        } else if (code.equals("970")) {
            countryName = "Palestine";
        } else if (code.equals("507")) {
            countryName = "Panama";
        } else if (code.equals("675")) {
            countryName = "Papua New Guinea";
        } else if (code.equals("595")) {
            countryName = "Paraguay";
        } else if (code.equals("51")) {
            countryName = "Peru";
        } else if (code.equals("63")) {
            countryName = "Philippines";
        } else if (code.equals("48")) {
            countryName = "Poland";
        } else if (code.equals("351")) {
            countryName = "Portugal";
        } else if (code.equals("974")) {
            countryName = "Qatar";
        } else if (code.equals("242")) {
            countryName = "Republic of the Congo";
        } else if (code.equals("40")) {
            countryName = "Romania";
        } else if (code.equals("250")) {
            countryName = "Rwanda";
        } else if (code.equals("290")) {
            countryName = "Saint Helena";
        }else if (code.equals("590")) {
            countryName = "Saint Martin";
        } else if (code.equals("508")) {
            countryName = "Saint Pierre and Miquelon";
        } else if (code.equals("685")) {
            countryName = "Samoa";
        } else if (code.equals("378")) {
            countryName = "San Marino";
        } else if (code.equals("239")) {
            countryName = "Sao Tome and Principe";
        } else if (code.equals("966")) {
            countryName = "Saudi Arabia";
        } else if (code.equals("221")) {
            countryName = "Senegal";
        } else if (code.equals("381")) {
            countryName = "Serbia";
        } else if (code.equals("248")) {
            countryName = "Seychelles";
        } else if (code.equals("232")) {
            countryName = "Sierra Leone";
        } else if (code.equals("65")) {
            countryName = "Singapore";
        } else if (code.equals("421")) {
            countryName = "Slovakia";
        } else if (code.equals("386")) {
            countryName = "Slovenia";
        } else if (code.equals("677")) {
            countryName = "Solomon Islands";
        } else if (code.equals("252")) {
            countryName = "Somalia";
        } else if (code.equals("27")) {
            countryName = "South Africa";
        } else if (code.equals("82")) {
            countryName = "South Korea";
        } else if (code.equals("211")) {
            countryName = "South Sudan";
        } else if (code.equals("34")) {
            countryName = "Spain";
        } else if (code.equals("94")) {
            countryName = "Sri Lanka";
        } else if (code.equals("249")) {
            countryName = "Sudan";
        } else if (code.equals("597")) {
            countryName = "Suriname";
        } else if (code.equals("268")) {
            countryName = "Swaziland";
        } else if (code.equals("46")) {
            countryName = "Sweden";
        } else if (code.equals("41")) {
            countryName = "Switzerland";
        } else if (code.equals("963")) {
            countryName = "Syria";
        } else if (code.equals("886")) {
            countryName = "Taiwan";
        } else if (code.equals("992")) {
            countryName = "Tajikistan";
        } else if (code.equals("255")) {
            countryName = "Tanzania";
        } else if (code.equals("66")) {
            countryName = "Thailand";
        } else if (code.equals("228")) {
            countryName = "Togo";
        } else if (code.equals("690")) {
            countryName = "Tokelau";
        } else if (code.equals("676")) {
            countryName = "Tonga";
        } else if (code.equals("216")) {
            countryName = "Tunisia";
        } else if (code.equals("90")) {
            countryName = "Turkey";
        } else if (code.equals("993")) {
            countryName = "Turkmenistan";
        } else if (code.equals("688")) {
            countryName = "Tuvalu";
        } else if (code.equals("256")) {
            countryName = "Uganda";
        } else if (code.equals("380")) {
            countryName = "Ukraine";
        } else if (code.equals("971")) {
            countryName = "United Arab Emirates";
        } else if (code.equals("598")) {
            countryName = "Uruguay";
        } else if (code.equals("998")) {
            countryName = "Uzbekistan";
        } else if (code.equals("678")) {
            countryName = "Vanuatu";
        } else if (code.equals("379")) {
            countryName = "Vatican";
        } else if (code.equals("58")) {
            countryName = "Venezuela";
        } else if (code.equals("84")) {
            countryName = "Vietnam";
        } else if (code.equals("681")) {
            countryName = "Wallis and Futuna";
        } else if (code.equals("967")) {
            countryName = "Yemen";
        } else if (code.equals("260")) {
            countryName = "Zambia";
        } else if (code.equals("263")) {
            countryName = "Zimbawe";
            // ... add other country codes and names
        } else if (code.equals("1")) {
            String countryOption = countryComboBox.getSelectedItem().toString();

            if (countryOption.equals("USA (+1)")) {
                countryName = "USA";
            } else if (countryOption.equals("Canada (+1)")) {
                countryName = "Canada";
                } else if (countryOption.equals("Antigua and Barbuda (+1)")) {
        countryName = "Antigua and Barbuda";
    } else if (countryOption.equals("Bahamas (+1)")) {
        countryName = "Bahamas";
    } else if (countryOption.equals("Barbados (+1)")) {
        countryName = "Barbados";
    } else if (countryOption.equals("Bermuda (+1)")) {
        countryName = "Bermuda";
    } else if (countryOption.equals("British Virgin Islands (+1)")) {
        countryName = "British Virgin Islands";
    } else if (countryOption.equals("Cayman Islands (+1)")) {
        countryName = "Cayman Islands";
    } else if (countryOption.equals("Dominica (+1)")) {
        countryName = "Dominica";
    } else if (countryOption.equals("Dominican Republic (+1)")) {
        countryName = "Dominican Republic";
    } else if (countryOption.equals("Grenada (+1)")) {
        countryName = "Grenada";
    } else if (countryOption.equals("Jamaica (+1)")) {
        countryName = "Jamaica";
    } else if (countryOption.equals("Montserrat (+1)")) {
        countryName = "Montserrat";
    } else if (countryOption.equals("Puerto Rico (+1)")) {
        countryName = "Puerto Rico";
    } else if (countryOption.equals("Saint Kitts and Nevis (+1)")) {
        countryName = "Saint Kitts and Nevis";
    } else if (countryOption.equals("Saint Lucia (+1)")) {
        countryName = "Saint Lucia";
    } else if (countryOption.equals("Saint Vincent and the Grenadines (+1)")) {
        countryName = "Saint Vincent and the Grenadines";
    } else if (countryOption.equals("Trinidad and Tobago (+1)")) {
        countryName = "Trinidad and Tobago";
    } else if (countryOption.equals("Turks and Caicos Islands (+1)")) {
        countryName = "Turks and Caicos Islands";
                // ... add other country options and names
            } else {
                // Invalid country code entered
                JOptionPane.showMessageDialog(null, "Country Code Invalid");
                return; // Skip updating the table if the country code is invalid
            }
        } else if (code.equals("44")) {
            String countryOption = countryComboBox.getSelectedItem().toString();

            if (countryOption.equals("United Kingdom (+44)")) {
                countryName = "United Kingdom";
                // ... add other country options and names
            } else {
                // Invalid country code entered
                JOptionPane.showMessageDialog(null, "Country Code Invalid");
                return; // Skip updating the table if the country code is invalid
            }
        } else {
            // Invalid country code entered
            JOptionPane.showMessageDialog(null, "Country Code Invalid");
            return; // Skip updating the table if the country code is invalid
        }

        String provinceName = "";
        String extractedNumber = "";
        Pattern pattern = Pattern.compile("\\((\\d+)\\)");
        Matcher matcher = pattern.matcher(telephone);
        if (matcher.find()) {
            extractedNumber = "(" + matcher.group(1) + ")";
        }

        String provinceOption = areacode.getSelectedItem().toString();

        if (provinceOption.equals("Metro Manila (02)")) {
    provinceName = "Metro Manila";
} else if (provinceOption.equals("Rizal (02)")) {
    provinceName = "Rizal";
} else if (provinceOption.equals("Cavite (02)")) {
    provinceName = "Cavite";
} else if (provinceOption.equals("Laguna (02)")) {
    provinceName = "Laguna";
} else if (provinceOption.equals("Cebu (32)")) {
    provinceName = "Cebu";
} else if (provinceOption.equals("Iloilo (33)")) {
    provinceName = "Iloilo";
} else if (provinceOption.equals("Guimaras (33)")) {
    provinceName = "Guimaras";
} else if (provinceOption.equals("Negros Occidental (34)")) {
    provinceName = "Negros Occidental";
} else if (provinceOption.equals("Negros Oriental (35)")) {
    provinceName = "Negros Oriental";
} else if (provinceOption.equals("Siquijor (35)")) {
    provinceName = "Siquijor";
} else if (provinceOption.equals("Aklan (36)")) {
    provinceName = "Aklan";
} else if (provinceOption.equals("Antique (36)")) {
    provinceName = "Antique";
} else if (provinceOption.equals("Capiz (36)")) {
    provinceName = "Capiz";
} else if (provinceOption.equals("Bohol (38)")) {
    provinceName = "Bohol";
} else if (provinceOption.equals("Aurora (42)")) {
    provinceName = "Aurora";
} else if (provinceOption.equals("Marinduque (42)")) {
    provinceName = "Marinduque";
} else if (provinceOption.equals("Quezon (42)")) {
    provinceName = "Quezon";
} else if (provinceOption.equals("Romblon (42)")) {
    provinceName = "Romblon";
} else if (provinceOption.equals("Batangas (43)")) {
    provinceName = "Batangas";
} else if (provinceOption.equals("Occidental Mindoro (43)")) {
    provinceName = "Occidental Mindoro";
} else if (provinceOption.equals("Oriental Mindoro (43)")) {
    provinceName = "Oriental Mindoro";
} else if (provinceOption.equals("Bulacan (44)")) {
    provinceName = "Bulacan";
} else if (provinceOption.equals("Nueva Ecija (44)")) {
    provinceName = "Nueva Ecija";
} else if (provinceOption.equals("Pampanga (45)")) {
    provinceName = "Pampanga";
} else if (provinceOption.equals("Tarlac (45)")) {
    provinceName = "Tarlac";
} else if (provinceOption.equals("Cavite (46)")) {
    provinceName = "Cavite";
} else if (provinceOption.equals("Bataan (47)")) {
    provinceName = "Bataan";
} else if (provinceOption.equals("Zambales (47)")) {
    provinceName = "Zambales";
} else if (provinceOption.equals("Palawan (48)")) {
    provinceName = "Palawan";
} else if (provinceOption.equals("Laguna (49)")) {
    provinceName = "Laguna";
} else if (provinceOption.equals("Albay (52)")) {
    provinceName = "Albay";
} else if (provinceOption.equals("Catanduanes (52)")) {
    provinceName = "Catanduanes";
} else if (provinceOption.equals("Biliran (53)")) {
    provinceName = "Biliran";
} else if (provinceOption.equals("Leyte (53)")) {
    provinceName = "Leyte";
} else if (provinceOption.equals("Southern Leyte (53)")) {
    provinceName = "Southern Leyte";
} else if (provinceOption.equals("Camarines Norte (54)")) {
    provinceName = "Camarines Norte";
} else if (provinceOption.equals("Camarines Sur (54)")) {
    provinceName = "Camarines Sur";
} else if (provinceOption.equals("Eastern Samar (55)")) {
    provinceName = "Eastern Samar";
} else if (provinceOption.equals("Northern Samar (55)")) {
    provinceName = "Northern Samar";
} else if (provinceOption.equals("Western Samar (55)")) {
    provinceName = "Western Samar";
} else if (provinceOption.equals("Masbate (56)")) {
    provinceName = "Masbate";
} else if (provinceOption.equals("Sorsogon (56)")) {
    provinceName = "Sorsogon";
} else if (provinceOption.equals("Basilan (62)")) {
    provinceName = "Basilan";
} else if (provinceOption.equals("Zamboanga del Sur (62)")) {
    provinceName = "Zamboanga del Sur";
} else if (provinceOption.equals("Zamboanga Sibugay (62)")) {
    provinceName = "Zamboanga Sibugay";
} else if (provinceOption.equals("Lanao del Norte (63)")) {
    provinceName = "Lanao del Norte";
} else if (provinceOption.equals("Lanao del Sur (63)")) {
    provinceName = "Lanao del Sur";
} else if (provinceOption.equals("Cotabato (64)")) {
    provinceName = "Cotabato";
} else if (provinceOption.equals("Maguindanao del Norte (64)")) {
    provinceName = "Maguindanao del Norte";
} else if (provinceOption.equals("Maguindanao del Sur (64)")) {
    provinceName = "Maguindanao del Sur";
} else if (provinceOption.equals("Sultan Kudarat (64)")) {
    provinceName = "Sultan Kudarat";
} else if (provinceOption.equals("Zamboanga del Norte (65)")) {
    provinceName = "Zamboanga del Norte";
} else if (provinceOption.equals("Sulu (68)")) {
    provinceName = "Sulu";
} else if (provinceOption.equals("Tawi-Tawi (68)")) {
    provinceName = "Tawi-Tawi";
} else if (provinceOption.equals("La Union (72)")) {
    provinceName = "La Union";
} else if (provinceOption.equals("Abra (74)")) {
    provinceName = "Abra";
} else if (provinceOption.equals("Apayao (74)")) {
    provinceName = "Apayao";
} else if (provinceOption.equals("Benguet (74)")) {
    provinceName = "Benguet";
} else if (provinceOption.equals("Ifugao (74)")) {
    provinceName = "Ifugao";
} else if (provinceOption.equals("Kalinga (74)")) {
    provinceName = "Kalinga";
} else if (provinceOption.equals("Mountain Province (74)")) {
    provinceName = "Mountain Province";
} else if (provinceOption.equals("Pangasinan (75)")) {
    provinceName = "Pangasinan";
} else if (provinceOption.equals("Ilocos Norte  (77)")) {
    provinceName = "Ilocos Norte";
} else if (provinceOption.equals("Ilocos Sur (77)")) {
    provinceName = "Ilocos Sur";
} else if (provinceOption.equals("Batanes (78)")) {
    provinceName = "Batanes";
} else if (provinceOption.equals("Cagayan (78)")) {
    provinceName = "Cagayan";
} else if (provinceOption.equals("Isabela (78)")) {
    provinceName = "Isabela";
} else if (provinceOption.equals("Nueva Vizcaya (78)")) {
    provinceName = "Nueva Vizcaya";
} else if (provinceOption.equals("Quirino (78)")) {
    provinceName = "Quirino";
} else if (provinceOption.equals("Davao del Sur (82)")) {
    provinceName = "Davao del Sur";
} else if (provinceOption.equals("Davao Occidental (82)")) {
    provinceName = "Davao Occidental";
} else if (provinceOption.equals("Sarangani (83)")) {
    provinceName = "Sarangani";
} else if (provinceOption.equals("South Cotabato (83)")) {
    provinceName = "South Cotabato";
} else if (provinceOption.equals("Davao de Oro (84)")) {
    provinceName = "Davao de Oro";
} else if (provinceOption.equals("Davao del Norte (84)")) {
    provinceName = "Davao del Norte";
} else if (provinceOption.equals("Agusan del Norte (85)")) {
    provinceName = "Agusan del Norte";
} else if (provinceOption.equals("Agusan del Sur (85)")) {
    provinceName = "Agusan del Sur";
} else if (provinceOption.equals("Dinagat Islands (86)")) {
    provinceName = "Dinagat Islands";
} else if (provinceOption.equals("Surigao del Norte (86)")) {
    provinceName = "Surigao del Norte";
} else if (provinceOption.equals("Surigao del Sur (86)")) {
    provinceName = "Surigao del Sur";
} else if (provinceOption.equals("Davao Oriental (87)")) {
    provinceName = "Davao Oriental";
} else if (provinceOption.equals("Bukidnon (88)")) {
    provinceName = "Bukidnon";
} else if (provinceOption.equals("Camiguin (88)")) {
    provinceName = "Camiguin";
} else if (provinceOption.equals("Misamis Occidental (88)")) {
    provinceName = "Misamis Occidental";
} else if (provinceOption.equals("Misamis Oriental (88)")) {
    provinceName = "Misamis Oriental";
            // ... add other province options and names
        } else {
            // Invalid province code entered
            JOptionPane.showMessageDialog(null, "Invalid Province Code");
            return; // Skip updating the table if the province code is invalid
        }

        // Set telephone and provinceName to "none" if jtelephone is not visible
        if (!jtelephone.isVisible()) {
            telephone = "none";
            provinceName = "none";
        }

        String dataToWrite = fullName + " " + lastName + " " + countryName+ " " + mobile + ""+ telephone + " "+provinceName;

        try {
            File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");

            if (isDataAlreadyExists(file, dataToWrite)) {
                // Data already exists, show a message or take appropriate action
                JOptionPane.showMessageDialog(null, "Data already exists on the Table.");
            } else if (fullName.isEmpty() || lastName.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out your first name and last name");
            } else if (mobile.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out your mobile number");
            } else if (code.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out your country code");
            } else if (telephone.isEmpty() && jtelephone.isVisible()) {
                JOptionPane.showMessageDialog(null, "Please fill out your telephone Number");
            } else if (mobile.length() < 10) {
                JOptionPane.showMessageDialog(null, "Please enter a mobile number with at least 10 characters");
            } else if (!telephone.matches("\\(.*\\).*") && jtelephone.isVisible()) {
                JOptionPane.showMessageDialog(null, "Please follow the telephone number format");
            } else {
                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                model.setValueAt(firstName, selectedRow, 0);
                model.setValueAt(lastName, selectedRow, 1);
                model.setValueAt(countryName, selectedRow, 2);
                model.setValueAt(mobile, selectedRow, 3);
                model.setValueAt(telephone, selectedRow, 4);
                model.setValueAt(provinceName, selectedRow, 5);

                FileWriter fw = new FileWriter(file, false);
                BufferedWriter bw = new BufferedWriter(fw);

                for (int i = 0; i < model.getRowCount(); i++) {
                    String rowData = "";
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        rowData += model.getValueAt(i, j) + " ";
                    }
                    bw.write(rowData.trim());
                    bw.newLine();
                }

                bw.close();
                fw.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
});


    }//GEN-LAST:event_jeditActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
String fullName = jname.getText().trim(); // Get the value from the jname TextField and trim any leading/trailing spaces
String firstName = fullName; // Store the fullName in the firstName variable
String lastName = jname2.getText().trim(); // Get the value from the jname2 TextField and trim any leading/trailing spaces
String mobile = jmobile.getText(); // Get the value from the jmobile TextField
String telephone = jtelephone.getText(); // Get the value from the jtelephone TextField
String code = jcode.getText(); // Get the value from the jcode TextField
String countryName = "";

// Set countryName based on countryComboBox selection
String countryOption = countryComboBox.getSelectedItem().toString(); // Get the selected item from the countryComboBox

if (code.equals("93")) {
    countryName = "Afghanistan";
} else if (code.equals("213")) {
    countryName = "Algeria";
    } else if (code.equals("376")) {
            countryName = "Andorra";
        } else if (code.equals("244")) {
            countryName = "Angola";
        } else if (code.equals("672")) {
            countryName = "Antartica";
        } else if (code.equals("54")) {
            countryName = "Argentina";
        } else if (code.equals("374")) {
            countryName = "Armenia";
        } else if (code.equals("297")) {
            countryName = "Aruba";
        } else if (code.equals("61")) {
            countryName = "Australia";
        } else if (code.equals("43")) {
            countryName = "Austria";
        } else if (code.equals("994")) {
            countryName = "Azerbaijan";
        } else if (code.equals("973")) {
            countryName = "Bahrain";
        } else if (code.equals("880")) {
            countryName = "Bangladesh";
        } else if (code.equals("375")) {
            countryName = "Belarus";
        } else if (code.equals("32")) {
            countryName = "Belgium";
        } else if (code.equals("501")) {
            countryName = "Belize";
        } else if (code.equals("229")) {
            countryName = "Benin";
        } else if (code.equals("975")) {
            countryName = "Bhutan";
        } else if (code.equals("387")) {
            countryName = "Bosnia and Herzegovina";
        } else if (code.equals("267")) {
            countryName = "Botswana";
        } else if (code.equals("55")) {
            countryName = "Brazil";
        } else if (code.equals("673")) {
            countryName = "Brunei";
        } else if (code.equals("359")) {
            countryName = "Bulgaria";
        } else if (code.equals("226")) {
            countryName = "Burkina Faso";
        } else if (code.equals("257")) {
            countryName = "Burundi";
        } else if (code.equals("855")) {
            countryName = "Cambodia";
        } else if (code.equals("237")) {
            countryName = "Cameroon";
        } else if (code.equals("238")) {
            countryName = "Cape Verde";
        } else if (code.equals("236")) {
            countryName = "Central African Republic";
        } else if (code.equals("235")) {
            countryName = "Chad";
        } else if (code.equals("56")) {
            countryName = "Chile";
        } else if (code.equals("86")) {
            countryName = "China";
        } else if (code.equals("57")) {
            countryName = "Colombia";
        } else if (code.equals("269")) {
            countryName = "Comoros";
        } else if (code.equals("682")) {
            countryName = "Cook Islands";
        } else if (code.equals("506")) {
            countryName = "Costa Rica";
        } else if (code.equals("385")) {
            countryName = "Croatia";
        } else if (code.equals("53")) {
            countryName = "Cuba";
        } else if (code.equals("599")) {
            countryName = "Curacao";
        } else if (code.equals("357")) {
            countryName = "Cyprus";
        } else if (code.equals("420")) {
            countryName = "Czech Republic";
        } else if (code.equals("243")) {
            countryName = "Democratic Republic of the Congo";
        } else if (code.equals("45")) {
            countryName = "Denmark";
        } else if (code.equals("253")) {
            countryName = "Djibouti";
        } else if (code.equals("670")) {
            countryName = "East Timor";
        } else if (code.equals("593")) {
            countryName = "Ecuador";
        } else if (code.equals("20")) {
            countryName = "Egypt";
        } else if (code.equals("503")) {
            countryName = "El Salvador";
        } else if (code.equals("240")) {
            countryName = "Equatorial Guinea";
        } else if (code.equals("291")) {
            countryName = "Eritrea";
        } else if (code.equals("372")) {
            countryName = "Estonia";
        } else if (code.equals("251")) {
            countryName = "Ethiopia";
        } else if (code.equals("500")) {
            countryName = "Falkland Islands";
        } else if (code.equals("298")) {
            countryName = "Faroe Islands";
        } else if (code.equals("679")) {
            countryName = "Fiji";
        } else if (code.equals("358")) {
            countryName = "Finland";
        } else if (code.equals("33")) {
            countryName = "France";
        } else if (code.equals("689")) {
            countryName = "French Polynesia";
        } else if (code.equals("241")) {
            countryName = "Gabon";
        } else if (code.equals("220")) {
            countryName = "Gambia";
        } else if (code.equals("995")) {
            countryName = "Georgia";
        } else if (code.equals("49")) {
            countryName = "Germany";
        } else if (code.equals("233")) {
            countryName = "Ghana";
        } else if (code.equals("350")) {
            countryName = "Gibraltar";
        } else if (code.equals("30")) {
            countryName = "Greece";
        } else if (code.equals("299")) {
            countryName = "Greenland";
        } else if (code.equals("1-671")) {
            countryName = "Guam";
        } else if (code.equals("502")) {
            countryName = "Guatemala";
        } else if (code.equals("224")) {
            countryName = "Guinea";
        } else if (code.equals("245")) {
            countryName = "Guinea-Bissau";
        } else if (code.equals("592")) {
            countryName = "Guyana";
        } else if (code.equals("509")) {
            countryName = "Haiti";
        } else if (code.equals("504")) {
            countryName = "Honduras";
        } else if (code.equals("852")) {
            countryName = "Hong Kong";
        } else if (code.equals("36")) {
            countryName = "Hungary";
        } else if (code.equals("354")) {
            countryName = "Iceland";
        } else if (code.equals("91")) {
            countryName = "India";
        } else if (code.equals("62")) {
            countryName = "Indonesia";
        } else if (code.equals("98")) {
            countryName = "Iran";
        } else if (code.equals("964")) {
            countryName = "Iraq";
        } else if (code.equals("353")) {
            countryName = "Ireland";
        } else if (code.equals("972")) {
            countryName = "Israel";
        } else if (code.equals("39")) {
            countryName = "Italy";
        } else if (code.equals("225")) {
            countryName = "Ivory Coast";
        } else if (code.equals("81")) {
            countryName = "Japan";
        } else if (code.equals("962")) {
            countryName = "Jordan";
        } else if (code.equals("254")) {
            countryName = "Kenya";
        } else if (code.equals("686")) {
            countryName = "Kiribati";
        } else if (code.equals("383")) {
            countryName = "Kosovo";
        } else if (code.equals("591")) {
            countryName = "Bolivia";
        } else if (code.equals("965")) {
            countryName = "Kuwait";
        } else if (code.equals("996")) {
            countryName = "Kyrgyzstan";
        } else if (code.equals("856")) {
            countryName = "Laos";
        } else if (code.equals("371")) {
            countryName = "Latvia";
        } else if (code.equals("961")) {
            countryName = "Lebanon";
        } else if (code.equals("266")) {
            countryName = "Lesotho";
        } else if (code.equals("231")) {
            countryName = "Liberia";
        } else if (code.equals("218")) {
            countryName = "Libya";
        } else if (code.equals("423")) {
            countryName = "Liechtenstein";
        } else if (code.equals("370")) {
            countryName = "Lithuania";
        } else if (code.equals("352")) {
            countryName = "Luxembourg";
        } else if (code.equals("853")) {
            countryName = "Macau";
        } else if (code.equals("389")) {
            countryName = "Macedonia";
        } else if (code.equals("261")) {
            countryName = "Madagascar";
        } else if (code.equals("265")) {
            countryName = "Malawi";
        } else if (code.equals("60")) {
            countryName = "Malaysia";
        } else if (code.equals("960")) {
            countryName = "Maldives";
        } else if (code.equals("223")) {
            countryName = "Mali";
        } else if (code.equals("356")) {
            countryName = "Malta";
        } else if (code.equals("692")) {
            countryName = "Marshall Islands";
        } else if (code.equals("222")) {
            countryName = "Mauritania";
        } else if (code.equals("230")) {
            countryName = "Mauritius";
        } else if (code.equals("262")) {
            countryName = "Mayotte";
        } else if (code.equals("52")) {
            countryName = "Mexico";
        } else if (code.equals("691")) {
            countryName = "Micronesia";
        } else if (code.equals("373")) {
            countryName = "Moldova";
        } else if (code.equals("377")) {
            countryName = "Monaco";
        } else if (code.equals("976")) {
            countryName = "Mongolia";
        } else if (code.equals("382")) {
            countryName = "Montenegro";
        } else if (code.equals("258")) {
            countryName = "Mozambique";
        } else if (code.equals("95")) {
            countryName = "Myanmar";
        } else if (code.equals("264")) {
            countryName = "Namibia";
        } else if (code.equals("674")) {
            countryName = "Nepal";
        } else if (code.equals("31")) {
            countryName = "Netherlands";
        } else if (code.equals("687")) {
            countryName = "New Caledonia";
        } else if (code.equals("64")) {
            countryName = "New Zealand";
        } else if (code.equals("505")) {
            countryName = "Nicaragua";
        } else if (code.equals("227")) {
            countryName = "Niger";
        } else if (code.equals("234")) {
            countryName = "Nigeria";
        } else if (code.equals("683")) {
            countryName = "Niue";
        } else if (code.equals("850")) {
            countryName = "North Korea";
        } else if (code.equals("47")) {
            countryName = "Norway";
        } else if (code.equals("968")) {
            countryName = "Oman";
        } else if (code.equals("92")) {
            countryName = "Pakistan";
        } else if (code.equals("680")) {
            countryName = "Palau";
        } else if (code.equals("970")) {
            countryName = "Palestine";
        } else if (code.equals("507")) {
            countryName = "Panama";
        } else if (code.equals("675")) {
            countryName = "Papua New Guinea";
        } else if (code.equals("595")) {
            countryName = "Paraguay";
        } else if (code.equals("51")) {
            countryName = "Peru";
        } else if (code.equals("63")) {
            countryName = "Philippines";
        } else if (code.equals("48")) {
            countryName = "Poland";
        } else if (code.equals("351")) {
            countryName = "Portugal";
        } else if (code.equals("974")) {
            countryName = "Qatar";
        } else if (code.equals("242")) {
            countryName = "Republic of the Congo";
        } else if (code.equals("40")) {
            countryName = "Romania";
        } else if (code.equals("250")) {
            countryName = "Rwanda";
        } else if (code.equals("290")) {
            countryName = "Saint Helena";
        }else if (code.equals("590")) {
            countryName = "Saint Martin";
        } else if (code.equals("508")) {
            countryName = "Saint Pierre and Miquelon";
        } else if (code.equals("685")) {
            countryName = "Samoa";
        } else if (code.equals("378")) {
            countryName = "San Marino";
        } else if (code.equals("239")) {
            countryName = "Sao Tome and Principe";
        } else if (code.equals("966")) {
            countryName = "Saudi Arabia";
        } else if (code.equals("221")) {
            countryName = "Senegal";
        } else if (code.equals("381")) {
            countryName = "Serbia";
        } else if (code.equals("248")) {
            countryName = "Seychelles";
        } else if (code.equals("232")) {
            countryName = "Sierra Leone";
        } else if (code.equals("65")) {
            countryName = "Singapore";
        } else if (code.equals("421")) {
            countryName = "Slovakia";
        } else if (code.equals("386")) {
            countryName = "Slovenia";
        } else if (code.equals("677")) {
            countryName = "Solomon Islands";
        } else if (code.equals("252")) {
            countryName = "Somalia";
        } else if (code.equals("27")) {
            countryName = "South Africa";
        } else if (code.equals("82")) {
            countryName = "South Korea";
        } else if (code.equals("211")) {
            countryName = "South Sudan";
        } else if (code.equals("34")) {
            countryName = "Spain";
        } else if (code.equals("94")) {
            countryName = "Sri Lanka";
        } else if (code.equals("249")) {
            countryName = "Sudan";
        } else if (code.equals("597")) {
            countryName = "Suriname";
        } else if (code.equals("268")) {
            countryName = "Swaziland";
        } else if (code.equals("46")) {
            countryName = "Sweden";
        } else if (code.equals("41")) {
            countryName = "Switzerland";
        } else if (code.equals("963")) {
            countryName = "Syria";
        } else if (code.equals("886")) {
            countryName = "Taiwan";
        } else if (code.equals("992")) {
            countryName = "Tajikistan";
        } else if (code.equals("255")) {
            countryName = "Tanzania";
        } else if (code.equals("66")) {
            countryName = "Thailand";
        } else if (code.equals("228")) {
            countryName = "Togo";
        } else if (code.equals("690")) {
            countryName = "Tokelau";
        } else if (code.equals("676")) {
            countryName = "Tonga";
        } else if (code.equals("216")) {
            countryName = "Tunisia";
        } else if (code.equals("90")) {
            countryName = "Turkey";
        } else if (code.equals("993")) {
            countryName = "Turkmenistan";
        } else if (code.equals("688")) {
            countryName = "Tuvalu";
        } else if (code.equals("256")) {
            countryName = "Uganda";
        } else if (code.equals("380")) {
            countryName = "Ukraine";
        } else if (code.equals("971")) {
            countryName = "United Arab Emirates";
        } else if (code.equals("598")) {
            countryName = "Uruguay";
        } else if (code.equals("998")) {
            countryName = "Uzbekistan";
        } else if (code.equals("678")) {
            countryName = "Vanuatu";
        } else if (code.equals("379")) {
            countryName = "Vatican";
        } else if (code.equals("58")) {
            countryName = "Venezuela";
        } else if (code.equals("84")) {
            countryName = "Vietnam";
        } else if (code.equals("681")) {
            countryName = "Wallis and Futuna";
        } else if (code.equals("967")) {
            countryName = "Yemen";
        } else if (code.equals("260")) {
            countryName = "Zambia";
        } else if (code.equals("263")) {
            countryName = "Zimbawe";
    // ... add other country codes and names

    if (countryOption.equals("Guernsey (+44)")) {
        countryName = "Guernsey";
    } else if (countryOption.equals("Jersey (+44)")) {
        countryName = "Jersey";
    } else if (countryOption.equals("United Kingdom (+44)")) {
        countryName = "United Kingdom";
    }
    // ... add other country options and names

} else if (code.equals("1")) {
    if (countryOption.equals("USA (+1)")) {
        countryName = "USA";
    } else if (countryOption.equals("Canada (+1)")) {
        countryName = "Canada";
        } else if (countryOption.equals("Antigua and Barbuda (+1)")) {
        countryName = "Antigua and Barbuda";
    } else if (countryOption.equals("Bahamas (+1)")) {
        countryName = "Bahamas";
    } else if (countryOption.equals("Barbados (+1)")) {
        countryName = "Barbados";
    } else if (countryOption.equals("Bermuda (+1)")) {
        countryName = "Bermuda";
    } else if (countryOption.equals("British Virgin Islands (+1)")) {
        countryName = "British Virgin Islands";
    } else if (countryOption.equals("Cayman Islands (+1)")) {
        countryName = "Cayman Islands";
    } else if (countryOption.equals("Dominica (+1)")) {
        countryName = "Dominica";
    } else if (countryOption.equals("Dominican Republic (+1)")) {
        countryName = "Dominican Republic";
    } else if (countryOption.equals("Grenada (+1)")) {
        countryName = "Grenada";
    } else if (countryOption.equals("Jamaica (+1)")) {
        countryName = "Jamaica";
    } else if (countryOption.equals("Montserrat (+1)")) {
        countryName = "Montserrat";
    } else if (countryOption.equals("Puerto Rico (+1)")) {
        countryName = "Puerto Rico";
    } else if (countryOption.equals("Saint Kitts and Nevis (+1)")) {
        countryName = "Saint Kitts and Nevis";
    } else if (countryOption.equals("Saint Lucia (+1)")) {
        countryName = "Saint Lucia";
    } else if (countryOption.equals("Saint Vincent and the Grenadines (+1)")) {
        countryName = "Saint Vincent and the Grenadines";
    } else if (countryOption.equals("Trinidad and Tobago (+1)")) {
        countryName = "Trinidad and Tobago";
    } else if (countryOption.equals("Turks and Caicos Islands (+1)")) {
        countryName = "Turks and Caicos Islands";
    }
    // ... add other country options and names

} else {
    // Invalid country code entered
    JOptionPane.showMessageDialog(null, "Country Code Invalid");
    return; // Skip displaying invalid country code on the jTable
}

String provinceName = "";
String extractedNumber = "";
Pattern pattern = Pattern.compile("\\((\\d+)\\)"); // Create a regex pattern to match the telephone number format
Matcher matcher = pattern.matcher(telephone); // Apply the pattern to the telephone number
if (matcher.find() && jtelephone.isVisible()) {
    extractedNumber = "(" + matcher.group(1) + ")"; // Extract the number within parentheses from the telephone number
}

String provinceOption = areacode.getSelectedItem().toString(); // Get the selected item from the areacode ComboBox

if (provinceOption.equals("Metro Manila (02)")) {
    provinceName = "Metro Manila";
} else if (provinceOption.equals("Rizal (02)")) {
    provinceName = "Rizal";
} else if (provinceOption.equals("Cavite (02)")) {
    provinceName = "Cavite";
} else if (provinceOption.equals("Laguna (02)")) {
    provinceName = "Laguna";
} else if (provinceOption.equals("Cebu (32)")) {
    provinceName = "Cebu";
} else if (provinceOption.equals("Iloilo (33)")) {
    provinceName = "Iloilo";
} else if (provinceOption.equals("Guimaras (33)")) {
    provinceName = "Guimaras";
} else if (provinceOption.equals("Negros Occidental (34)")) {
    provinceName = "Negros Occidental";
} else if (provinceOption.equals("Negros Oriental (35)")) {
    provinceName = "Negros Oriental";
} else if (provinceOption.equals("Siquijor (35)")) {
    provinceName = "Siquijor";
} else if (provinceOption.equals("Aklan (36)")) {
    provinceName = "Aklan";
} else if (provinceOption.equals("Antique (36)")) {
    provinceName = "Antique";
} else if (provinceOption.equals("Capiz (36)")) {
    provinceName = "Capiz";
} else if (provinceOption.equals("Bohol (38)")) {
    provinceName = "Bohol";
} else if (provinceOption.equals("Aurora (42)")) {
    provinceName = "Aurora";
} else if (provinceOption.equals("Marinduque (42)")) {
    provinceName = "Marinduque";
} else if (provinceOption.equals("Quezon (42)")) {
    provinceName = "Quezon";
} else if (provinceOption.equals("Romblon (42)")) {
    provinceName = "Romblon";
} else if (provinceOption.equals("Batangas (43)")) {
    provinceName = "Batangas";
} else if (provinceOption.equals("Occidental Mindoro (43)")) {
    provinceName = "Occidental Mindoro";
} else if (provinceOption.equals("Oriental Mindoro (43)")) {
    provinceName = "Oriental Mindoro";
} else if (provinceOption.equals("Bulacan (44)")) {
    provinceName = "Bulacan";
} else if (provinceOption.equals("Nueva Ecija (44)")) {
    provinceName = "Nueva Ecija";
} else if (provinceOption.equals("Pampanga (45)")) {
    provinceName = "Pampanga";
} else if (provinceOption.equals("Tarlac (45)")) {
    provinceName = "Tarlac";
} else if (provinceOption.equals("Cavite (46)")) {
    provinceName = "Cavite";
} else if (provinceOption.equals("Bataan (47)")) {
    provinceName = "Bataan";
} else if (provinceOption.equals("Zambales (47)")) {
    provinceName = "Zambales";
} else if (provinceOption.equals("Palawan (48)")) {
    provinceName = "Palawan";
} else if (provinceOption.equals("Laguna (49)")) {
    provinceName = "Laguna";
} else if (provinceOption.equals("Albay (52)")) {
    provinceName = "Albay";
} else if (provinceOption.equals("Catanduanes (52)")) {
    provinceName = "Catanduanes";
} else if (provinceOption.equals("Biliran (53)")) {
    provinceName = "Biliran";
} else if (provinceOption.equals("Leyte (53)")) {
    provinceName = "Leyte";
} else if (provinceOption.equals("Southern Leyte (53)")) {
    provinceName = "Southern Leyte";
} else if (provinceOption.equals("Camarines Norte (54)")) {
    provinceName = "Camarines Norte";
} else if (provinceOption.equals("Camarines Sur (54)")) {
    provinceName = "Camarines Sur";
} else if (provinceOption.equals("Eastern Samar (55)")) {
    provinceName = "Eastern Samar";
} else if (provinceOption.equals("Northern Samar (55)")) {
    provinceName = "Northern Samar";
} else if (provinceOption.equals("Western Samar (55)")) {
    provinceName = "Western Samar";
} else if (provinceOption.equals("Masbate (56)")) {
    provinceName = "Masbate";
} else if (provinceOption.equals("Sorsogon (56)")) {
    provinceName = "Sorsogon";
} else if (provinceOption.equals("Basilan (62)")) {
    provinceName = "Basilan";
} else if (provinceOption.equals("Zamboanga del Sur (62)")) {
    provinceName = "Zamboanga del Sur";
} else if (provinceOption.equals("Zamboanga Sibugay (62)")) {
    provinceName = "Zamboanga Sibugay";
} else if (provinceOption.equals("Lanao del Norte (63)")) {
    provinceName = "Lanao del Norte";
} else if (provinceOption.equals("Lanao del Sur (63)")) {
    provinceName = "Lanao del Sur";
} else if (provinceOption.equals("Cotabato (64)")) {
    provinceName = "Cotabato";
} else if (provinceOption.equals("Maguindanao del Norte (64)")) {
    provinceName = "Maguindanao del Norte";
} else if (provinceOption.equals("Maguindanao del Sur (64)")) {
    provinceName = "Maguindanao del Sur";
} else if (provinceOption.equals("Sultan Kudarat (64)")) {
    provinceName = "Sultan Kudarat";
} else if (provinceOption.equals("Zamboanga del Norte (65)")) {
    provinceName = "Zamboanga del Norte";
} else if (provinceOption.equals("Sulu (68)")) {
    provinceName = "Sulu";
} else if (provinceOption.equals("Tawi-Tawi (68)")) {
    provinceName = "Tawi-Tawi";
} else if (provinceOption.equals("La Union (72)")) {
    provinceName = "La Union";
} else if (provinceOption.equals("Abra (74)")) {
    provinceName = "Abra";
} else if (provinceOption.equals("Apayao (74)")) {
    provinceName = "Apayao";
} else if (provinceOption.equals("Benguet (74)")) {
    provinceName = "Benguet";
} else if (provinceOption.equals("Ifugao (74)")) {
    provinceName = "Ifugao";
} else if (provinceOption.equals("Kalinga (74)")) {
    provinceName = "Kalinga";
} else if (provinceOption.equals("Mountain Province (74)")) {
    provinceName = "Mountain Province";
} else if (provinceOption.equals("Pangasinan (75)")) {
    provinceName = "Pangasinan";
} else if (provinceOption.equals("Ilocos Norte  (77)")) {
    provinceName = "Ilocos Norte";
} else if (provinceOption.equals("Ilocos Sur (77)")) {
    provinceName = "Ilocos Sur";
} else if (provinceOption.equals("Batanes (78)")) {
    provinceName = "Batanes";
} else if (provinceOption.equals("Cagayan (78)")) {
    provinceName = "Cagayan";
} else if (provinceOption.equals("Isabela (78)")) {
    provinceName = "Isabela";
} else if (provinceOption.equals("Nueva Vizcaya (78)")) {
    provinceName = "Nueva Vizcaya";
} else if (provinceOption.equals("Quirino (78)")) {
    provinceName = "Quirino";
} else if (provinceOption.equals("Davao del Sur (82)")) {
    provinceName = "Davao del Sur";
} else if (provinceOption.equals("Davao Occidental (82)")) {
    provinceName = "Davao Occidental";
} else if (provinceOption.equals("Sarangani (83)")) {
    provinceName = "Sarangani";
} else if (provinceOption.equals("South Cotabato (83)")) {
    provinceName = "South Cotabato";
} else if (provinceOption.equals("Davao de Oro (84)")) {
    provinceName = "Davao de Oro";
} else if (provinceOption.equals("Davao del Norte (84)")) {
    provinceName = "Davao del Norte";
} else if (provinceOption.equals("Agusan del Norte (85)")) {
    provinceName = "Agusan del Norte";
} else if (provinceOption.equals("Agusan del Sur (85)")) {
    provinceName = "Agusan del Sur";
} else if (provinceOption.equals("Dinagat Islands (86)")) {
    provinceName = "Dinagat Islands";
} else if (provinceOption.equals("Surigao del Norte (86)")) {
    provinceName = "Surigao del Norte";
} else if (provinceOption.equals("Surigao del Sur (86)")) {
    provinceName = "Surigao del Sur";
} else if (provinceOption.equals("Davao Oriental (87)")) {
    provinceName = "Davao Oriental";
} else if (provinceOption.equals("Bukidnon (88)")) {
    provinceName = "Bukidnon";
} else if (provinceOption.equals("Camiguin (88)")) {
    provinceName = "Camiguin";
} else if (provinceOption.equals("Misamis Occidental (88)")) {
    provinceName = "Misamis Occidental";
} else if (provinceOption.equals("Misamis Oriental (88)")) {
    provinceName = "Misamis Oriental";
}
// ... add other province options and names

if (!jtelephone.isVisible()) {
    telephone = "none"; // Set telephone to "none" if jtelephone is not visible
    provinceName = "none"; // Set provinceName to "none" if jtelephone is not visible
} else if (extractedNumber.equals(telephone)) {
    provinceName = "None"; // Set provinceName to "None" if the extracted number matches the full telephone value
}

String dataToWrite = fullName + " " + lastName + " " + countryName+ " " + mobile + ""+ telephone + " "+provinceName;
// The remaining code remains the same.
// ...
try {
    File file = new File("C:\\Users\\ADMIN\\Desktop\\PhoneDetails\\phonedetails.txt");

    // Check if data already exists in the file
    if (isDataAlreadyExists(file, dataToWrite)) {
        // Data already exists, show a message or take appropriate action
        JOptionPane.showMessageDialog(null, "Data already exists on the Table.");
    } else if (fullName.isEmpty() || lastName.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your first name and last name");
    } else if (mobile.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your mobile number");
    } else if (code.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please fill out your country code");
    } else if (telephone.isEmpty() && jtelephone.isVisible()) {
        JOptionPane.showMessageDialog(null, "Please fill out your telephone Number");
    } else if (mobile.length() < 10) {
        JOptionPane.showMessageDialog(null, "Please enter a mobile number with at least 10 characters");
    } else if (!telephone.matches("\\(.*\\).*") && jtelephone.isVisible()) {
        JOptionPane.showMessageDialog(null, "Please follow the telephone number format");
    } else {
        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(dataToWrite);
        bw.newLine();
        bw.close();
        fw.close();

        // Add data to the table only if it's not already present
        boolean isDataAlreadyInTable = false;
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0).equals(firstName)) {
                isDataAlreadyInTable = true;
                break;
            }
        }

        if (!isDataAlreadyInTable) {
            model.addRow(new Object[]{fullName,lastName,countryName,mobile,telephone,provinceName});
        }
    }
} catch (IOException ex) {
    Logger.getLogger(FinalExam.class.getName()).log(Level.SEVERE, null, ex);
}




    }//GEN-LAST:event_jButton1ActionPerformed

    private void jtelephoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtelephoneActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jtelephoneActionPerformed

    private void jtelephoneFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtelephoneFocusLost
        // TODO add your handling code here:
        if(jtelephone.getText().equals(""))
        {
            jtelephone.setText("Telephone Number (xx)xxx-xxxx");
        }
    }//GEN-LAST:event_jtelephoneFocusLost

    private void jtelephoneFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtelephoneFocusGained
        // TODO add your handling code here:
        if(jtelephone.getText().equals("Telephone Number (xx)xxx-xxxx"))
        {
            jtelephone.setText("");
        }
    }//GEN-LAST:event_jtelephoneFocusGained

    private void countryComboBoxKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_countryComboBoxKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_countryComboBoxKeyTyped

    private void countryComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countryComboBoxActionPerformed
        // TODO add your handling code here:
        countryComboBox.setVisible(false);
    }//GEN-LAST:event_countryComboBoxActionPerformed

    private void jsearchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jsearchKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jsearchKeyTyped

    private void jsearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jsearchKeyReleased
        // TODO add your handling code here:
        DefaultTableModel obj =(DefaultTableModel) jTable1.getModel();
        TableRowSorter<DefaultTableModel> obj1 = new TableRowSorter<>(obj);
        jTable1.setRowSorter(obj1);
        obj1.setRowFilter(RowFilter.regexFilter(jsearch.getText()));
    }//GEN-LAST:event_jsearchKeyReleased

    private void jsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jsearchActionPerformed

    private void jsearchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jsearchFocusLost
        // TODO add your handling code here:
        if(jsearch.getText().equals(""))
        {
            jsearch.setText("Search");
        }
    }//GEN-LAST:event_jsearchFocusLost

    private void jsearchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jsearchFocusGained
        // TODO add your handling code here:
        if(jsearch.getText().equals("Search"))
        {
            jsearch.setText("");
        }
    }//GEN-LAST:event_jsearchFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FinalExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FinalExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FinalExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FinalExam.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FinalExam().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> areacode;
    private javax.swing.JButton clear;
    private javax.swing.JComboBox<String> countryComboBox;
    private javax.swing.JButton exit;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jcode;
    private javax.swing.JButton jdelete;
    private javax.swing.JButton jedit;
    private javax.swing.JTextField jmobile;
    private javax.swing.JTextField jname;
    private javax.swing.JTextField jname2;
    private javax.swing.JButton jsave;
    private javax.swing.JTextField jsearch;
    private javax.swing.JTextField jtelephone;
    // End of variables declaration//GEN-END:variables
}
